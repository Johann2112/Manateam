using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace Manateam 
{
    public class musica : MonoBehaviour
    {
        public AudioSource sonidos;
        public Movement movement;

        void Start()
        {
            sonidos = GetComponent<AudioSource>();
            movement = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
        }

        // Update is called once per frame
        void Update()
        {
            if (movement.dead == true)
                sonidos.mute = true;
            else
                sonidos.mute = false;
        }
    }
}
