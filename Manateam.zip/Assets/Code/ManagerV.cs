using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Manateam 
{
    public class ManagerV : MonoBehaviour
    {
        public float speed = 5; 
        public float aumentoVelocidad;  
        private void FixedUpdate()
        {
            speed += aumentoVelocidad;
        }
    }
}
