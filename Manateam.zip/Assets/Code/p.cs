using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Manateam 
{
    public class p : MonoBehaviour
{    
    private float left;
    ManagerV velocidad;    


    private void Start()
    {
        left = Camera.main.ScreenToWorldPoint(Vector3.zero).x - 1f;
        velocidad = GameObject.FindGameObjectWithTag("ManagerV").GetComponent<ManagerV>();
    }

    private void Update()
    {
        transform.position += Vector3.left * velocidad.speed * Time.deltaTime;
        if(transform.position.x < left)
        {
            Destroy(gameObject);
        }        
    }
    
}

}
