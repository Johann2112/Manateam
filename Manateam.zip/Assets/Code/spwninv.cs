using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Manateam 
{
    public class spwninv : MonoBehaviour
{
    [SerializeField] GameObject prefab;
    [SerializeField] float spawnR = 1f;
    [SerializeField] float t;
    private float[] arreglo = new float[5] {0.1f,0.2f,0.3f,0.4f,0.5f};
    
    [SerializeField] float minH = -1f;
    [SerializeField] float maxH = 1f;
    private void OnEnable()
    {
        InvokeRepeating(nameof(Spawn), spawnR, t + arreglo[Random.Range(0,5)]);
    }

    private void OnDisable()
    {
        CancelInvoke(nameof(Spawn));
    }

    private void Spawn()
    {
        GameObject p = Instantiate(prefab, transform.position, Quaternion.identity);
        p.transform.position += Vector3.up * Random.Range(minH, maxH);
        p.transform.rotation = Quaternion.Euler(0, 0 , 180);
    }
    private void OnDrawGizmos()
    {
        Vector2 pos = transform.position;
        Gizmos.DrawLine(pos + Vector2.up * minH, pos + Vector2.up * maxH);
    }
}
}
