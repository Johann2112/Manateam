using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;

namespace Manateam 
{
    public class HealthBar : MonoBehaviour
    {

        [SerializeField] private float maxHealth = 100;
        public float currentHealth;
        [SerializeField] private Image healthBarFill;
        [SerializeField] private float fillSpeed;
        [SerializeField] private Gradient colorGradient;
        ScoreValue sV;
        public float hLoseOverTime;

        public Movement fallecio;

        // Start is called before the first frame update
        void Start()
        {
            currentHealth = maxHealth;
            sV = GameObject.FindGameObjectWithTag("Items").GetComponent<ScoreValue>();
        }

        public void UpdateHealth(float amount)
        {
            currentHealth += amount;
            currentHealth = Mathf.Clamp(currentHealth, 0f, maxHealth);
            UpdateHealthBar();
        }

        private void FixedUpdate()
        {
            UpdateHealth(-hLoseOverTime);
            if(currentHealth >= maxHealth)
            {
                currentHealth = maxHealth;
            }

            if(currentHealth <= 0)
            {
                fallecio.dead = true;
            }
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.CompareTag("Items"))
            {
                UpdateHealth(sV.lifeValue);
            }
        }



        private void UpdateHealthBar()
        {
            float TargetFillAmount = currentHealth / maxHealth;
            // healthBarFill.fillAmount = TargetFillAmount;
            healthBarFill.DOFillAmount(TargetFillAmount, fillSpeed);
            //healthBarFill.color = colorGradient.Evaluate(TargetFillAmount);
            healthBarFill.DOColor(colorGradient.Evaluate(TargetFillAmount), fillSpeed);
        }
    }
}
