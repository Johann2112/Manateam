using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Manateam 
{
    public class freeze : MonoBehaviour
    {
        void Awake ()
        {
            Time.timeScale = 0;
        }
        public void Onpressisonar()
        {
            Time.timeScale = 1;
        }    
    }


}
