using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Manateam 
{
    public class RestartMenu : MonoBehaviour
    {
        Movement fallecio;
        public GameObject restartButton;
        public bool isOnMenu;

        void Awake()
        {

            fallecio = GameObject.FindGameObjectWithTag("Player").GetComponent<Movement>();
            restartButton = GameObject.FindGameObjectWithTag("RestartMenu");
            restartButton.SetActive(false);
            Time.timeScale = 0f;
            isOnMenu = false;
        }
        private void Start()
        {
            restartButton.SetActive(false);
            
            isOnMenu = false;
        }


        void Update()
        {
            if (fallecio.dead == true)
            {
                openMenu();
            }
            else
            {
                closeMenu();
            }
        }
        public void openMenu()
        {
            restartButton.SetActive(true);
            Time.timeScale = 0f;
            isOnMenu = true;
        }

        public void closeMenu()
        {
            restartButton.SetActive(false);
            isOnMenu = false;
        }
    }
}
