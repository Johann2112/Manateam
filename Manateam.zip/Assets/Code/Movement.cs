using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Manateam 
{
    public class Movement : MonoBehaviour
    {    
        [SerializeField] Rigidbody2D rb;
        [SerializeField] float speed;
        private bool moveUp;
        private bool moveDown;
        private float verticalMovement;
        [SerializeField] float max;
        public bool dead = false;
        public float velocidadDeCaidaMax;
        public float VelocidadSiSePasa;


        void Awake()
        {
        rb = GetComponent<Rigidbody2D>();
        }
        void update ()
        {
            if(rb.velocity.y < -velocidadDeCaidaMax)
            {
                rb.velocity= new Vector2 (0,-VelocidadSiSePasa);
            }    
        }
        void Start()
        {
            moveUp = false;
            //moveDown = false;
            rb.gravityScale = 2f;
        }

        public void PointerDownUp() // cuando apretas el boton "arriba"
        {
            moveUp = true;
        }
        public void PointerUpUp() // cuando sueltas el boton "arriba"
        {
            moveUp = false;
        }
        /*public void PointerDownDown() // cuando apretas el boton "abajo"
        {
            moveDown = true;
        }
        public void PointerUpDown() //cuando sueltas el boton "abajo"
        {
            moveDown = false;
        }*/
        // Update is called once per frame
        void FixedUpdate()
        {
            PlayerMovement();
        }
        private void PlayerMovement()
        {
            if (moveUp)
            {
                rb.AddForce(new Vector2(0, speed));
                Vector2 r = rb.velocity;
                r.y = Mathf.Clamp(r.y, -max/2, max * 1.25f);
                rb.velocity = r;
            }

            /*else if (moveDown)
            {
                verticalMovement = -speed;
            }
            else
            {
                verticalMovement = 0;
            }*/
        }

        /*private void FixedUpdate()
        {
            rb.velocity = new Vector2(0 , verticalMovement);
        }*/

        private void OnCollisionEnter2D(Collision2D collision)
        {
            if(collision.gameObject.CompareTag("obstaculo") || collision.gameObject.CompareTag("roca flotante"))
            {
                Destroy(collision.gameObject);
                dead = true;
            }
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            if(collision.CompareTag("Items"))
            {
                Destroy(collision.gameObject);
            }
        }
    }

}
