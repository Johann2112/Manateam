using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Manateam 
{
    public class spwanobjs : MonoBehaviour
    {
        [SerializeField] GameObject prefab;
        [SerializeField] float spawnR = 1f;
        [SerializeField] float spawnD;
        [SerializeField] float minH = -1f;
        [SerializeField] float maxH = 1f;
        [SerializeField] Transform world;
        [SerializeField] LayerMask obstacleL;

        private void OnEnable()
        {
            InvokeRepeating(nameof(Spawn), spawnR, spawnD);
        }

        private void OnDisable()
        {
            CancelInvoke(nameof(Spawn));
        }

        private void Spawn()
        {
            Vector3 spawnPosition;
            int maxAttempts = 10; 
            int attempts = 0;

            do
            {
                spawnPosition = transform.position + Vector3.up * Random.Range(minH, maxH);
                attempts++;
            } while (Physics2D.OverlapCircle(spawnPosition, 3f, obstacleL) && attempts < maxAttempts);

            if (attempts < maxAttempts)
            {
                GameObject spawnedItem = Instantiate(prefab, spawnPosition, Quaternion.identity);
                spawnedItem.transform.SetParent(world);
            }
        }
    }
}
