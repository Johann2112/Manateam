using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Manateam 
{
    public class TutorialC : MonoBehaviour
    {
        public void LoadScene()
        {
            SceneManager.LoadScene(1);
        }
    }
}
