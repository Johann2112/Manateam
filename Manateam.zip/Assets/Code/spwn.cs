using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Manateam 
{
    public class spwn : MonoBehaviour
    {
        [SerializeField] GameObject prefab;
        [SerializeField] float spawnR = 1f;
        [SerializeField] float spawnD;
        [SerializeField] float minH = -1f;
        [SerializeField] float maxH = 1f;
        [SerializeField] float minS= 1f;
        private float[] arreglo = new float[5] {0.05f,0.1f,0.25f,0.35f,0.45f};
        private Vector3 lSpawnP;

        private void OnEnable()
        {
            InvokeRepeating(nameof(Spawn), spawnR, spawnD + arreglo[Random.Range(0, 5)]);
            lSpawnP= transform.position;
        }

        private void OnDisable()
        {
            CancelInvoke(nameof(Spawn));
        }

        private void Spawn()
        {
            Vector3 spawnPosition;

            do
            {
                spawnPosition = transform.position + Vector3.up * Random.Range(minH, maxH);
            } while (Vector3.Distance(spawnPosition, lSpawnP) < minS);

            GameObject p = Instantiate(prefab, spawnPosition, Quaternion.identity);
            lSpawnP = spawnPosition;
        }
        private void OnDrawGizmos()
        {
            Vector2 pos = transform.position;
            Gizmos.DrawLine(pos + Vector2.up * minH, pos + Vector2.up * maxH);
        }
    }
}
