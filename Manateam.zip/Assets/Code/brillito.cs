using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

namespace Manateam 
{
    public class brillito : MonoBehaviour
    {

    }
}
