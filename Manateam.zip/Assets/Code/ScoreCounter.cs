using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace Manateam 
{
    public class ScoreCounter : MonoBehaviour
    {
        // Start is called before the first frame update

        [SerializeField]
        UnityEvent<string> textscore;


        public float score = 0;
        public float hola = 0;

        private void Start()
        {
            textscore.Invoke(" Puntaje : " + score);
        }


        private void Update()
        {
            
        }
        private void FixedUpdate()
        {
            textscore.Invoke(" Puntaje : " + score);
        }

        private void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.CompareTag("Items"))
            {
                score += collision.GetComponent<ScoreValue>().Value;            
                Destroy(collision.gameObject);
            }
        }
    }
}
