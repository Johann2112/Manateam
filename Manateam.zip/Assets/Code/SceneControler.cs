using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Manateam 
{
    public class SceneControler : MonoBehaviour
    {

        public bool vioAd;

        public void Start()
        {
                vioAd = true;
        }

        public Movement fallecio;
        public HealthBar bar;

        public void VideoContinue()
        {

            if (vioAd)
            {
                fallecio.dead = false;
                Time.timeScale = 1;
            
            if(bar.currentHealth < 75)
                bar.currentHealth = 80;

                vioAd = false;
            }
            else if (!vioAd)
            {
                Debug.Log("Ya vistes un anuncion >:(");
            }
            
        }

        public void LoadScene()
        {
            SceneManager.LoadScene(0);
        }
        //public void QuitGame() //para el futuro boton de salir del juego
        //{
          //  Application.Quit();
        //}
    }
}
