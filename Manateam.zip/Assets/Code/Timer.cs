using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

namespace Manateam 
{
    public class Timer : MonoBehaviour
    {

        [SerializeField] TextMeshProUGUI timer;
        [SerializeField]private float time = 0;
        public ScoreCounter sC;
        public float waitForSeconds = 1.25f;
    
        private void Update()
        {

            time += Time.deltaTime;
            int sec = (int)time % 60;
            int min = (int)time / 60;
            if(sec % 60 == 59)
            {
                sC.hola = 1;
            }
            if(sC.hola == 1)
            StartCoroutine(AddPointsByMinute());
            
            
            timer.SetText(string.Format("{0:00}:{1:00}", min, sec));
        }
        private IEnumerator AddPointsByMinute()
        {
            yield return new WaitForSeconds(waitForSeconds);
            if (sC.hola == 1)
            {
                sC.score += 45;
            }
            sC.hola = 0;
        }
        
    }

}
